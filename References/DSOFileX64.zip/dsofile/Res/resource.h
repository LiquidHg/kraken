//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dsofile.rc
//
#define IDR_TYPELIB                     1
#define MSG_DSO_E_DOCUMENTNOTOPEN       1
#define MSG_DSO_E_DOCUMENTOPENED        2
#define MSG_DSO_E_DOCUMENTLOCKED        3
#define MSG_DSO_E_NODOCUMENTPROPS       4
#define MSG_DSO_E_DOCUMENTREADONLY      5
#define MSG_DSO_E_MUSTHAVESTORAGE       6
#define MSG_DSO_E_INVALIDOBJECT         7
#define MSG_DSO_E_INVALIDPROPSET        8
#define MSG_DSO_E_INVALIDINDEX          9
#define MSG_DSO_E_ITEMEXISTS           10

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
